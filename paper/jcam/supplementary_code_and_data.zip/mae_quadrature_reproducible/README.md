# Reproducible Partial-Moment Stieltjes Quadrature Package

This repository reproduces the main numerical claims for the published
rounded \(n=4\) quadrature hierarchy using a separate verification code
path.

## Quick start

```bash
python -m pip install -r requirements.txt
python run_all.py
```

The second command:

1. reconstructs moments, alternation points and centered errors;
2. recomputes structural errors and Chebyshev transfer functions;
3. evaluates deterministic selector spot checks;
4. repeats the shifted-Lorentzian primary-box stress test;
5. regenerates the principal figures;
6. runs the full automated audit suite.

A nonzero exit code means at least one frozen-reference comparison failed.

## Repository structure

```text
paper/          manuscript, theorem appendix, references
rules/          published rounded nodes and weights
src/            independent reproduction formulas
tests/          audit tests against frozen reference data
data/reference/ frozen values used only for post-computation checks
results/        regenerated numerical tables
figures/        regenerated figures
run_all.py      one-command entry point
```

## Scientific scope

The package verifies the distributed rounded rules. It does not solve
the original nonlinear minimax optimization problem from scratch.

The alternation and exact moment theory apply to ideal exact-moment
rules. The coefficient-box and mixed-risk formulas apply to any fixed
rule, including the rounded published rules.

The shifted-family experiment is an external-validity stress test, not a
shifted-pole optimality theorem.

## Expected outputs

- `results/hierarchy_reproduction.csv`
- `results/moment_audit.csv`
- `results/alternation_points.csv`
- `results/structural_errors.csv`
- `results/transfer_functions.csv`
- `results/selector_spots.csv`
- `results/shifted_primary_box.csv`
- `results/run_manifest.json`
- four figures in `figures/`

## Reproducibility status

This is an internal independent reimplementation in a separate code path.
It is not a third-party replication or a proof-assistant verification.
